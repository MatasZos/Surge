// Energy resource system
