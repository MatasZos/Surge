// Main menu scene
