// Main gameplay scene
