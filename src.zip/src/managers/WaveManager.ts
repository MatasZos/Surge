// Wave spawning and progression
